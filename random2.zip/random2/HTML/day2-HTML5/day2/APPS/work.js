

function counter() {
    var msg="Web workers kdsjfkjdsh kfjhsdkjfhdsjkfhk jdshfjds";
     
    postMessage(msg);
    
}
counter();