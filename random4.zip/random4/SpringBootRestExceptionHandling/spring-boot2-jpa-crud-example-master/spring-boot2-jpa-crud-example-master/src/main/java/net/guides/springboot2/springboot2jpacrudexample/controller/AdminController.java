package net.guides.springboot2.springboot2jpacrudexample.controller;

public class AdminController {

}
