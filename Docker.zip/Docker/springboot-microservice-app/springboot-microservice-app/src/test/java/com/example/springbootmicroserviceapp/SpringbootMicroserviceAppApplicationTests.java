package com.example.springbootmicroserviceapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootMicroserviceAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
