package com.example.springbootmicroserviceapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootMicroserviceAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootMicroserviceAppApplication.class, args);
	}

}
